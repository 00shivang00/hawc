#!/usr/bin/env python
################################################################################
# A demonstration of how to call the AERIE detector-service inside of python.  #
#                                                                              #
# To use this program AERIE must be installed and /path/to/aerie/lib must be   #
# included in your PYTHONPATH environment variable.  The environment is set up #
# with the hawc-config script:                                                 #
#                                                                              #
#   $> eval `/path/to/aerie/bin/hawc-config --env-sh`                          #
################################################################################


from xcdf import XCDFFile
import math
import sys
import energyflow as ef
from energyflow.datasets import qg_jets
from energyflow.utils import data_split, standardize, to_categorical
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt
import random

import os
import numpy as np
from optparse import OptionParser
import matplotlib.pyplot as plt
import curses 
from collections import defaultdict

import pickle

from PosLookUp import *
n=0

def save_obj(obj, name ):
    with open('obj/'+ name + '.pkl', 'wb') as f:
        pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)



scale = 250.0

minE = 50
maxE = 1000
dpth = "/media/shivang/xcd/data.xcd"
gpth = "/media/shivang/xcd/gamma.xcd"

#for num in range(0,9):
	#name = "proton{}.xcd".format(num)


					#12 = index for last item



#(1,2,8),(2,3,6) (2,3)
def expandPosEv(ev, d):

	
	for i in range(len(ev[1])):
		x,y = ev[1][i],ev[2][i]

		R = (x**2 + y**2)**.5
		t = np.arctan(y/x)
		R += d*R
		
		x = R*np.cos(t)
		y = R*np.sin(t)
		
		ev[1][i] = x
		ev[2][i] = y
	return ev


def expandQEv(ev, d):
	evc = [i[:] for i in ev]
	for i in range(len(evc[1])):
		evc[0][i] = evc[0][i]*d
	return evc
	


def clean(d, n, flatten=False):
	for i in d.keys():
		if len(d[i]) < n:
			del d[i]
		elif flatten and len(d[i]) > n:
			d[i] = d[i][:n]
	return d	

def load_obj(name ):
    with open('obj/' + name + '.pkl', 'rb') as f:
        return pickle.load(f)

def emd_dist(s1, s2):
	return ef.emd.emd(s1, s2, measure='spherical')

def compare(ev, gset, dset, n):
	gdist = []
	ddist = []
	gam=True 
	for i in range(n):
		gdist.append((emd_dist(ev, gset[i]),gam))
		ddist.append((emd_dist(ev, dset[i]),not(gam)))
	f = sorted((gdist + ddist), key=lambda x: x[0])
	return (len(filter(lambda x: x[1], f[:n])) > n/2)

eCount = {}
fCount = {}
stage = [[1,2,3,4,5,6,7,8]]
paths = [ "none","fid", "fid-and-zen", "zen" ]
paths = [ "none" ]
ev = None
pret = None

DEFhit_test_dict = load_obj("datatest");
GEFhit_test_dict = load_obj("gammatest");

DEFhit_train_dict = load_obj("datatrain");
GEFhit_train_dict = load_obj("gammatrain");
print("loaded dictionaries")
'''
print("data test: \n")
for i in sorted(DEFhit_test_dict.keys()):
	print("in " + str(i) +": "+str(len(DEFhit_test_dict[i])))
print("\n------------------------------------\n")
print("gamma test: \n")
for i in sorted(GEFhit_test_dict.keys()):
	print("in " + str(i) +": "+str(len(GEFhit_test_dict[i])))

print("\n------------------------------------")
print("------------------------------------")

print("data train: \n")
for i in sorted(DEFhit_train_dict.keys()):
	print("in " + str(i) +": "+str(len(DEFhit_train_dict[i])))
print("\n------------------------------------\n")
print("gamma train: \n")
for i in sorted(GEFhit_train_dict.keys()):
	print("in " + str(i) +": "+str(len(GEFhit_train_dict[i])))
'''
DEFhit_train_dict = clean(DEFhit_train_dict,20)
DEFhit_test_dict = clean(DEFhit_test_dict,10) 
GEFhit_train_dict = clean(GEFhit_train_dict,20)
GEFhit_test_dict = clean(GEFhit_test_dict,10) 

print("configured dictionaries")

keys = sorted(list(set(DEFhit_train_dict.keys()) & set(GEFhit_train_dict.keys()) & set(DEFhit_test_dict.keys()) & set(GEFhit_test_dict.keys())))
print("keys:")
for i in keys:
	print(i)

GEFhit_train_dict = clean(GEFhit_train_dict,20)
GEFhit_test_dict = clean(GEFhit_test_dict,10) 
print("Gamma:\n")

for i in keys:
	gset = GEFhit_train_dict[i]
	dset = DEFhit_train_dict[i]

	res = []
	for ev in GEFhit_test_dict[i]:
		res.append(compare(ev, gset, dset, 20))
	print("key: " + str(i) + "...." + "for " + str(len(GEFhit_test_dict[i])) +" events: \t"  + str(round(float(len([k for k in res if k]))/float(len(res)),3)))


DEFhit_train_dict = clean(DEFhit_train_dict,20)
DEFhit_test_dict = clean(DEFhit_test_dict,10) 
print("\nData:\n")

for i in keys:
	gset = GEFhit_train_dict[i]
	dset = DEFhit_train_dict[i]

	res = []
	for ev in DEFhit_test_dict[i]:
		res.append(compare(ev, gset, dset, 20))
	print("key: " + str(i) + "...." + "for " + str(len(DEFhit_test_dict[i])) +" events: \t" + str(round(float(len([k for k in res if k]))/float(len(res)),3)))
