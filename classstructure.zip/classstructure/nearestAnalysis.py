from __future__ import division
from xcdf import XCDFFile
import math
import sys
import energyflow as ef
from energyflow.datasets import qg_jets
from energyflow.utils import data_split, standardize, to_categorical
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt
import random


import os
import numpy as np
from optparse import OptionParser
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import curses 
from collections import defaultdict
from scipy.spatial.transform import Rotation as R
import pickle
from PosLookUp import *
from Event import *

class KNearest:
	def __init__(self, ref, n=33):
		self.ref = ref
		self.nearest = []
		self.n = n
		
	def add(self, ev):
		emd = self.ref.compare(ev)
		e = (emd, ev)
		if(len(self.nearest) == 0):
			self.nearest.append(e)
			return
		if((emd == 0.0)):
			return 
		if e in self.nearest:
			return
		
			
		if((len(self.nearest) == self.n) and (self.nearest[-1][0] <= emd)):
			return
			
		if((len(self.nearest) < self.n) or ((len(self.nearest) == self.n) and (self.nearest[-1][0] >= emd))):
			if((len(self.nearest) == self.n)):
				del self.nearest[-1]
			
			
			for i in range(len(self.nearest)):
				if((self.nearest[i][0] >= emd)):
					self.nearest.insert(i, e)
					return
			
			self.nearest.append(e)
		return



def load_obj(name ):
    with open('/media/shivang/xcd/obj/' + name + '.pkl', 'rb') as f:
        return pickle.load(f)
        
data56 = load_obj('d-3-3-0-2170-events')[(3,3,0)][1:1002]
gam56 = load_obj('g-3-3-0-8057-events')[(3,3,0)][1:1002]

print("loaded")

evGam = [Event(0,0,0,0,0,0,0,0,0).listLoad(l) for l in gam56]
evData = [Event(0,0,0,0,0,0,0,0,0).listLoad(l) for l in data56]

gamRef = evGam[1]
dataRef = evData[1]
print("gamma ", gamRef.par_type)
print("data ", dataRef.par_type)
g2gQ = KNearest(gamRef)
d2gQ = KNearest(gamRef)
g2dQ = KNearest(dataRef)
d2dQ = KNearest(dataRef)
general2gQ = KNearest(gamRef)
general2dQ = KNearest(dataRef)

print("begin KNearest")
n = 0
general2dQ.add(dataRef)
for i in evGam:
	
	n+=1
	if(n%100 == 0):
		print(str(n) + " analyzed")
	g2gQ.add(i)
	g2dQ.add(i)
	general2gQ.add(i)
	general2dQ.add(i)
print("gamma processed")

n=0
for i in evData:
	
	n+=1
	if(n%100 == 0):
		print(str(n) + " analyzed")
	d2gQ.add(i)
	d2dQ.add(i)
	general2gQ.add(i)
	general2dQ.add(i)
print("data processed")

print("gamma 2 gamma: ", [round(i[0],6) for i in g2gQ.nearest])
print("gamma 2 data: ", [round(i[0],6) for i in g2dQ.nearest])
print("data 2 gamma: ", [round(i[0],6) for i in d2gQ.nearest])
print("data 2 data: ", [round(i[0],6) for i in d2dQ.nearest])
print("all 2 gamma: ", [round(i[0],6) for i in general2gQ.nearest])
print("all 2 data: ", [round(i[0],6) for i in general2dQ.nearest])
'''
print("gamma 2 gamma: ", [i for i in g2gQ.nearest])
print("gamma 2 data: ", [i for i in g2dQ.nearest])
print("data 2 gamma: ", [i for i in d2gQ.nearest])
print("data 2 data: ", [i for i in d2dQ.nearest])
print("all 2 gamma: ", [i for i in general2gQ.nearest])
print("all 2 data: ", [i for i in general2dQ.nearest])
'''

print(general2dQ.nearest[0] == general2dQ.nearest[1])

for i in g2gQ.nearest:
	i[1].plotSpace(i[0],'gamma2gamma/')
	
for i in d2gQ.nearest:
	i[1].plotSpace(i[0],'data2gamma/')
	
for i in g2dQ.nearest:
	i[1].plotSpace(i[0],'gamma2data/')
	
for i in d2dQ.nearest:
	i[1].plotSpace(i[0],'data2data/')
	
for i in general2gQ.nearest:
	i[1].plotSpace(i[0],'all2gamma/')
	
for i in general2dQ.nearest:
	i[1].plotSpace(i[0],'all2data/')
	



