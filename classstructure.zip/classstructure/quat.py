#!/usr/bin/env python
################################################################################
# A demonstration of how to call the AERIE detector-service inside of python.  #
#                                                                              #
# To use this program AERIE must be installed and /path/to/aerie/lib must be   #
# included in your PYTHONPATH environment variable.  The environment is set up #
# with the hawc-config script:                                                 #
#                                                                              #
#   $> eval `/path/to/aerie/bin/hawc-config --env-sh`                          #
################################################################################

import csv
import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial.transform import Rotation as R
from pyquaternion import Quaternion 
		
		
class Event:
	def __init__(self, xcore, ycore, N, E, F, Z, A, Eb, Fb):
		self.xC = xcore
		self.yC = ycore
		self.nHit = N
		self.LTeV = E
		self.fHit = F
		self.zen = Z
		self.az = A
		self.fbin = Fb
		self.ebin = Eb
		self.eta = []
		self.phi = []
		self.Q = []
		self.zeros = []
		self.par_type = ""
		self.transformed = False
		
	def transform(self):
		if(not(self.transformed)):
			transform(self)
		self.transformed = True
		
	def mean(self):
		return [np.mean(self.eta), np.mean(self.phi)]
	
	def variance(self):
		v1 = sum([((j - np.mean(self.eta))**2)/len(self.eta) for j in eta ])
		v2 = sum([((j - np.mean(self.phi))**2)/len(self.phi) for j in phi ])
		return [v1, v2]
		
	def std(self):
		return ([i**.5 for i in self.variance()])
	
	def RMS(self):
		return [round(np.sqrt(np.mean([i**2 for i in self.eta])),4), round(np.sqrt(np.mean([i**2 for i in self.phi])),4)]
		
	def plot(self):
		b1 = np.linspace(-5,5, 35)
		b2 = np.linspace(-5,5, 35)
		
		plt.clf()
		plt.title('Eta:(zen= {}, az= {}, log(TeV)= {}, fHit= {})'.format(self.zen, self.az, self.LTeV, self.fHit))
		plt.hist(self.eta, bins = b1)
		EtaH, EtaBins = np.histogram(self.eta, bins = b1)
		plt.ylim((0, max(EtaH) * 1.5))
		plt.text(3, max(EtaH),'Entries: {} \nRMS: {} \nMean: {} \nVar: {}\n STD: {}'.format(len(self.eta), round(np.sqrt(np.mean([i**2 for i in self.eta])),4),
		round(np.mean(self.eta), 4), round(np.var(self.eta) ,4), round(np.std(self.eta), 4)), ha='left', va='bottom')
		plt.savefig('img/{} {}_{} Eta.png'.format(self.par_type, n2l[self.ebin], self.fbin))


		plt.clf()
		plt.title('Phi:(zen= {}, az= {}, log(TeV)= {}, fHit= {})'.format(self.zen, self.az, self.LTeV, self.fHit))
		plt.hist(self.phi, bins = b2)
		PhiH, PhiBins = np.histogram(self.phi, bins = b2)
		plt.ylim((0, max(PhiH) * 1.5))
		plt.text(2, max(PhiH),'Entries: {} \nRMS: {} \nMean: {} \nVar: {} \nSTD: {}'.format(len(self.phi), round(np.sqrt(np.mean([i**2 for i in self.phi])),4), 
		round(np.mean(self.phi), 4), round(np.var(self.phi),4), round(np.std(self.phi), 4)), ha='left', va='bottom')
		plt.savefig('img/{} {}_{} Phi.png'.format(self.par_type, n2l[self.ebin], self.fbin))
		
	def get_ev(self):
		return [[self.Q, self.eta, self.phi, self.zeros], self.zen, self.az]
		
def max_x(e, n):
	return max([max(e[i][0][n]) for i in range(0, len(e))])

def min_x(e, n):
	return min([min(e[i][0][n]) for i in range(0, len(e))])

def dot(x, y):
    return sum([x[i] * y[i] for i in range(len(x))])

def v_len(x):
    return (dot(x, x))**.5

def normal(x):
    return [x[i] / v_len(x) for i in range(len(x))]

def project_onto_plane(x, n):
    d = dot(x, n)
    p = [d * normal(n)[i] for i in range(len(n))]
    return [x[i] - p[i] for i in range(len(x))]


def proj(x,y,zen,az):
	n = s2rec(zen,az)
	v = [x,y,0]
	p = project_onto_plane(v,n)
	return rt(zen, az,p)
	
def s2rec(theta,phi):
	x = np.sin(theta)*np.cos(phi)
	y = np.sin(theta)*np.sin(phi)
	z = np.cos(theta)
	return [x,y,z]

def rec2s(v):
	r = sum([i**2 for i in v])
	t = np.arctan(v[1]/v[0])
	p = np.arctan(((v[0]**2+v[1]**2)**.5)/v[2])
	return [r,t,p]
	
def avg(l):
	return sum(l)/len(l)

def rt(theta,phi,v):
	phi = -phi
	theta = -theta
	Rx = np.array([[1,0,0],
				  [0, np.cos(theta),-np.sin(theta)],
				  [0, np.sin(theta),np.cos(theta)]])

	Rz = np.array([[ np.cos(phi),-np.sin(phi),0],
				  [ np.sin(phi),np.cos(phi),0],
				  [0,0,1]])
				  
	Ry = np.array([[np.cos(theta),0,np.sin(theta)],
				   [0,1,0],
				   [-np.sin(theta),0,np.cos(theta)]])
	r = R.from_matrix(Ry.dot(Rz))

	return r.apply(v)

def transform(ev):
	az = ev.az + np.pi
	zen = ev.zen
	for i in range(len(ev.zeros)):
		v = proj(ev.eta[i], ev.phi[i],zen,az)
		ev.eta[i], ev.phi[i] = -1*v[0], -1*v[1]
		
	
