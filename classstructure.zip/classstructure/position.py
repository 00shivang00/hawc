#!/usr/bin/env python
################################################################################
# A demonstration of how to call the AERIE detector-service inside of python.  #
#                                                                              #
# To use this program AERIE must be installed and /path/to/aerie/lib must be   #
# included in your PYTHONPATH environment variable.  The environment is set up #
# with the hawc-config script:                                                 #
#                                                                              #
#   $> eval `/path/to/aerie/bin/hawc-config --env-sh`                          #
################################################################################

from __future__ import division
from xcdf import XCDFFile
import math
import sys
import energyflow as ef
from energyflow.datasets import qg_jets
from energyflow.utils import data_split, standardize, to_categorical
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt
import random

import os
import numpy as np
from optparse import OptionParser
import matplotlib.pyplot as plt
import curses 
from collections import defaultdict
from PosLookUp import *
from scipy.spatial.transform import Rotation as R

n=0


scale = 250.0

minE = 50
maxE = 1000
name = "/media/shivang/xcd/gamma.xcd"

#for num in range(0,9):
	#name = "proton{}.xcd".format(num)


					#12 = index for last item


eCount = {}
fCount = {}
stage = [[0,1,2],[3,4,5],[6,7,8]]
paths = [ "none","fid", "fid-and-zen", "zen"]

for pI in range(len(paths)):
	print(paths[pI] + ": ")
	
	for fB in stage:
		xf = XCDFFile(name)
		fin = []
		n = 1
		k = 0
		if fB == -1:
			continue
		EFhit_dict = {}
		print("searching: ",fB)
		#for r in xf.fields(" event.nHit, event.hit.gridId, event.hit.charge, rec.zenithAngle, rec.azimuthAngle, rec.coreX, rec.coreY, rec.nChAvail, rec.logNNEnergy, rec.coreFitStatus, rec.angleFitStatus, rec.coreFiduScale"):
		for r in xf.fields(" event.nHit, event.hit.gridId, event.hit.charge, rec.zenithAngle, rec.azimuthAngle, rec.coreX, rec.coreY, rec.nChAvail, rec.logNNEnergy, rec.coreFitStatus, rec.angleFitStatus, rec.coreFiduScale, mc.delAngle"):
			
			nHit, ids, Q, zen, az, xC, yC, nCh, logGeV, coreFit, angFit, fid, delAng = r
			#nHit, ids, Q, zen, az, xC, yC, nCh, logGeV, coreFit, angFit, fid = r
			#0     1   2   3    4   5   6   7    8        9         10    11
			if n%100000 == 0:
				print("explored vs found in this bin: " + str(n) + " vs " + str(k))	
			

			fh = (1.0 * nHit)/(1.0 * nCh)
			E = 10**(logGeV - 3)
			en = eNum(E)
			fn = fNum(fh)
			if ((fn in fB) and (en > -1)):
				
				
				if((en,fn) in fin) or (((en, fn) in EFhit_dict.keys()) and (EFhit_dict[(en, fn)].n >= 10000)):
					n+=1
					if (en, fn) not in fin:
						fin.append((en,fn))
						EFhit_dict[(en, fn)].plot()	
						print("finished: " + str((en, fn)))
						EFhit_dict[(en, fn)] = None
					continue
				
				
				bools = [((angFit + coreFit) == 0) and (fid <= 150), ((angFit + coreFit) == 0) and (fid <= 80), ((angFit + coreFit) == 0) and (zen <= 0.523) and (fid <= 80), ((angFit + coreFit) == 0) and (zen <= 0.523)]
				#if((delAng < .087) and ((angFit + coreFit) == 0) and (fid <= 150)):
				if((delAng < .087) and bools[pI]):
					k+=1
					ev = Event(xC, yC, nHit, E, fh, zen, az, en, fn)
					ev.par_type = "gamma"
					for i in range(0,nHit):
						ind = ids[i]	#pmt index
						
						if(ind<1124):
							ev.zeros.append(0.0)
							ev.Q.append(Q[i])							#charge
							ev.eta.append(np.pi*((xCh[ind]-xC)/scale))	#X position from core (eta)
							ev.phi.append(np.pi*((yCh[ind]-yC)/scale))	#Y position from core (phi)
					
					if((en, fn) not in EFhit_dict.keys()):
						EFhit_dict[(en, fn)] = Collection(en, fn, "gamma", paths[pI])
					ev.transform()
					EFhit_dict[(en, fn)].add_event(ev)
			n+=1
			if n == 2E6 :
				break

		for i in sorted(EFhit_dict.keys()):
			if (EFhit_dict[i] != None):
				print("key: " + str(i) + ": " + str(EFhit_dict[i].n))
				EFhit_dict[i].plot()				
	
#.................................................................................................					

name = "/media/shivang/xcd/data.xcd"

#for num in range(0,9):
	#name = "proton{}.xcd".format(num)

xf = XCDFFile(name)
					#12 = index for last item


eCount = {}
fCount = {}
stage = [[0,1,2],[3,4,5],[6,7,8]]
paths = [ "none","fid", "fid-and-zen", "zen"]

for pI in range(len(paths)):
	print(paths[pI] + ": ")
	
	for fB in stage:
		
		xf = XCDFFile(name)
		fin = []
		n = 1
		k = 0
		if fB == -1:
			continue
		EFhit_dict = {}
		print("searching: ",fB)
		for r in xf.fields(" event.nHit, event.hit.gridId, event.hit.charge, rec.zenithAngle, rec.azimuthAngle, rec.coreX, rec.coreY, rec.nChAvail, rec.logNNEnergy, rec.coreFitStatus, rec.angleFitStatus, rec.coreFiduScale"):
		#for r in xf.fields(" event.nHit, event.hit.gridId, event.hit.charge, rec.zenithAngle, rec.azimuthAngle, rec.coreX, rec.coreY, rec.nChAvail, rec.logNNEnergy, rec.coreFitStatus, rec.angleFitStatus, rec.coreFiduScale, mc.delAngle"):
			
			#nHit, ids, Q, zen, az, xC, yC, nCh, logGeV, coreFit, angFit, fid, delAng = r
			nHit, ids, Q, zen, az, xC, yC, nCh, logGeV, coreFit, angFit, fid = r
			#0     1   2   3    4   5   6   7    8        9         10    11
			if n%100000 == 0:
				print("explored vs found in this bin: " + str(n) + " vs " + str(k))	
			

			fh = (1.0 * nHit)/(1.0 * nCh)
			E = 10**(logGeV - 3)
			en = eNum(E)
			fn = fNum(fh)
			if ((fn in fB) and (en > -1)):
				
				
				if((en,fn) in fin) or (((en, fn) in EFhit_dict.keys()) and (EFhit_dict[(en, fn)].n >= 10000)):
					n+=1
					if (en, fn) not in fin:
						fin.append((en,fn))
						EFhit_dict[(en, fn)].plot()	
						print("finished: " + str((en, fn)))
						EFhit_dict[(en, fn)] = None
					continue
				
				
				bools = [((angFit + coreFit) == 0) and (fid <= 150), ((angFit + coreFit) == 0) and (fid <= 80), ((angFit + coreFit) == 0) and (zen <= 0.523) and (fid <= 80), ((angFit + coreFit) == 0) and (zen <= 0.523)]
				if(bools[pI]):
				#if((delAng < .087) and bools[pI]):
					k+=1
					ev = Event(xC, yC, nHit, E, fh, zen, az, en, fn)
					ev.par_type = "data"
					for i in range(0,nHit):
						ind = ids[i]	#pmt index
						
						if(ind<1124):
							ev.ones.append(1.0)
							ev.Q.append(Q[i])							#charge
							ev.eta.append(np.pi*((xCh[ind]-xC)/scale))	#X position from core (eta)
							ev.phi.append(np.pi*((yCh[ind]-yC)/scale))	#Y position from core (phi)
					
					if((en, fn) not in EFhit_dict.keys()):
						EFhit_dict[(en, fn)] = Collection(en, fn, "data", paths[pI])
					ev.transform()
					EFhit_dict[(en, fn)].add_event(ev)
			n+=1
			if n == 2E6 :
				break

		for i in sorted(EFhit_dict.keys()):
			if (EFhit_dict[i] != None):
				print("key: " + str(i) + ": " + str(EFhit_dict[i].n))
				EFhit_dict[i].plot()		
	



