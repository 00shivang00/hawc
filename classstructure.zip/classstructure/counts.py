#!/usr/bin/env python
################################################################################
# A demonstration of how to call the AERIE detector-service inside of python.  #
#                                                                              #
# To use this program AERIE must be installed and /path/to/aerie/lib must be   #
# included in your PYTHONPATH environment variable.  The environment is set up #
# with the hawc-config script:                                                 #
#                                                                              #
#   $> eval `/path/to/aerie/bin/hawc-config --env-sh`                          #
################################################################################

from __future__ import division
import ROOT
from matplotlib.colors import LogNorm
from xcdf import XCDFFile
import math
import sys
import energyflow as ef
from energyflow.datasets import qg_jets
from energyflow.utils import data_split, standardize, to_categorical
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt
import random
from tabulate import tabulate
import os
import numpy as np
from optparse import OptionParser
import matplotlib.pyplot as plt
import curses 
from collections import defaultdict

from PosLookUp import *
n=0


scale = 250.0

minE = 50
maxE = 1000
#name = "/media/shivang/xcd/gamma.xcd"
name = "/media/shivang/xcd/data.xcd"

#for num in range(0,9):
	#name = "proton{}.xcd".format(num)


					#12 = index for last item

lim = 2E6
base_count = {}
cut_count = {}



paths = ["fid <= 150", "fid <= 80", "fid <= 80 and zen <= 0.523", "zen <= 0.523"]
for pI in [0,1,2,3]:
	xf = XCDFFile(name)
	baseEs = []
	baseFs = []

	cutEs = []
	cutFs = []
	print(paths[pI] + ": ")
	n=0
	#for r in xf.fields(" event.nHit, event.hit.gridId, event.hit.charge, rec.zenithAngle, rec.azimuthAngle, rec.coreX, rec.coreY, rec.nChAvail, rec.logNNEnergy, rec.coreFitStatus, rec.angleFitStatus, rec.coreFiduScale, mc.delAngle"):
	for r in xf.fields(" event.nHit, event.hit.gridId, event.hit.charge, rec.zenithAngle, rec.azimuthAngle, rec.coreX, rec.coreY, rec.nChAvail, rec.logNNEnergy, rec.coreFitStatus, rec.angleFitStatus, rec.coreFiduScale"):
			n+=1
			
			if n%250000 == 0:
				print("explored in this bin: " + str(n))	
			#nHit, ids, Q, zen, az, xC, yC, nCh, logGeV, coreFit, angFit, fid, delAng = r
			nHit, ids, Q, zen, az, xC, yC, nCh, logGeV, coreFit, angFit, fid= r
			#0     1   2   3    4   5   6   7    8        9         10    11
			
				

			fh = (1.0 * nHit)/(1.0 * nCh)
			E = 10**(logGeV - 3)
			bools = [((angFit + coreFit) == 0) and (fid <= 150), ((angFit + coreFit) == 0) and (fid <= 80), ((angFit + coreFit) == 0) and (zen <= 0.523) and (fid <= 80), ((angFit + coreFit) == 0) and (zen <= 0.523)]
					

			#if((delAng < .087) and bools[pI]):
			if(bools[pI]):
				cutEs.append(eNum(E))
				cutFs.append(fNum(fh))

			if n == lim:
				break
	b = [[0,1,2,3,4,5,6,7,8],[0,1,2,3,4,5,6,7,8,9,10,11]]
	baseEs = np.array(baseEs)
	baseFs = np.array(baseFs)

	cutEs = np.array(cutEs)
	cutFs = np.array(cutFs)





	plt.hist2d(cutFs, cutEs, bins = b,  norm=LogNorm())
	plt.colorbar()
	plt.ylabel("Energy Bin")
	plt.xlabel("Fhit Bin")
	plt.title("Event Count with " + paths[pI])
	plt.savefig(paths[pI]+".png")
	plt.clf()





