from __future__ import division
from xcdf import XCDFFile
import math
import sys
import energyflow as ef
from energyflow.datasets import qg_jets
from energyflow.utils import data_split, standardize, to_categorical
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt
import random


import os
import xlsxwriter
import numpy as np
from optparse import OptionParser
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import curses 
from collections import defaultdict
from scipy.spatial.transform import Rotation as R
import pickle
from PosLookUp import *
import PosLookUp as ps
from Event import *
import os.path
from os import path

EFBins = [(1,1), (2,1), (3,1), (4,1), (1,2), (2,2), (3,2), (4,2), (5,2), 
(2,3), (3,3), (4,3), (5,3), (6,3), (3,4), (4,4), (5,4), (6,4), (7,4), (4,5), (5,5), (6,5), (7,5), 
(5,6), (6,6), (7,6), (8,6), (6,7), (7,7), (8,7), (9,7), (6,8), (7,8), (8,8), (9,8), (10,8), 
(7,9), (8,9), (9,9), (10,9), (11,9), (12,9)]

def load_obj(name ):
    with open(name, 'rb') as f:
        return pickle.load(f)
        
def plot(MD, l, name):
	d = []
	r = l[0]
	lp = l[:]
	cutlabel = np.log10(float(MD))
	
	'''
	r.plotSpace(0.0,"")
	for i in l[1:]:
		n = r.compare(i)
		if(n <= MD or MD < 0):
			d.append(r.compare(i))
	'''
	NEv = 0
	passed = 0
	while(len(lp) >= 2):
		NEv += 1
		e1 = random.choice(lp)
		lp.remove(e1)
		e2 = random.choice(lp)
		lp.remove(e2)
		n = e1.compare(e2)
		if((n <= MD or MD < 0) and (n>0)):
			n = np.log10(n)
			if(n>0 and n<np.inf):
				d.append(n)
			passed+=1
		
		
	d = [i for i in d if ~np.isnan(i)]
	
	
	plt.clf()
	plt.hist(d,40)
	EMDh = np.histogram(d,40)
	plt.title("EMD from {} to {} events".format(name, name))
	plt.ylabel("Frequency")
	plt.xlabel("log(EMD)")
	yt = len(d)**.5
	plt.yscale("log")
	yt = np.log(len(d)) * 1.5
	plt.text(EMDh[1][-1]*.7, yt ,'Entries: {} \nRMS: {} \nMean: {} \nVar: {} \nSTD: {} \nmedian: {}'.format(len(d), round(np.sqrt(np.mean([i**2 for i in d])),4), 
			round(np.mean(d), 4), round(np.var(d),4), round(np.std(d), 4), round(sorted(d)[len(d)//2],4)), ha='left', va='bottom')
	
	plt.savefig('img/{}-EMD-cut@10**{}.png'.format(name, cutlabel))
	
        
def plot2(MD, l, r, name1, name2):
	d = []
	cutlabel = np.log10(float(MD))
	lp = l[:]
	rp = r[:]
	
	
	'''
	r.plotSpace(0.0,"")
	for i in l[1:]:
		n = r.compare(i)
		if(n <= MD or MD < 0):
			d.append(r.compare(i))
	'''
	
	while((len(lp) + len(rp)) >= 2):
		e1 = random.choice(lp)
		lp.remove(e1)
		e2 = random.choice(rp)
		rp.remove(e2)
		n = e1.compare(e2)
		if((n <= MD or MD < 0) and (n > 0)):
			n = np.log10(n)
			if(n>0 and n<np.inf):
				d.append(n)
		
		
	d = [i for i in d if ~np.isnan(i)]
	
	
	plt.clf()
	plt.hist(d,40)
	EMDh = np.histogram(d,40)
	plt.title("EMD from {} to {} events".format(name1, name2))
	plt.ylabel("Frequency")
	plt.xlabel("log10(EMD)")
	yt = len(d)**.5
	plt.yscale("log")
	yt = np.log(len(d))*1.5
	plt.text(EMDh[1][-1]*.7, yt ,'Entries: {} \nRMS: {} \nMean: {} \nVar: {} \nSTD: {} \nmedian: {}'.format(len(d), round(np.sqrt(np.mean([i**2 for i in d])),4), 
			round(np.mean(d), 4), round(np.var(d),4), round(np.std(d), 4), round(sorted(d)[len(d)//2],4)), ha='left', va='bottom')
	
	plt.savefig('img/log-{}-to-{}-EMD-cut@10**{}.png'.format(name1, name2, cutlabel))
	
def RandComp1(l):
	lp = l[:]

	
	d = []
	MD = 10**40
	while(len(lp) >= 2):
		e1 = random.choice(lp)
		lp.remove(e1)
		e2 = random.choice(lp)
		lp.remove(e2)
		n = e1.compare(e2)
		if((n <= MD or MD < 0) and (n>0)):
			n = np.log10(n)
			if(n>0 and n<np.inf):
				d.append(n)

	
	return d

def RandComp2(l, r):
	lp = l[:]
	rp = r[:]
	d = []
	MD = 10**40
	while((len(lp) + len(rp)) >= 2):
		e1 = random.choice(lp)
		lp.remove(e1)
		e2 = random.choice(rp)
		rp.remove(e2)
		n = e1.compare(e2)
		if((n <= MD or MD < 0) and (n > 0)):
			n = np.log10(n)
			if(n>0 and n<np.inf):
				d.append(n)
	
	return d

def cumulativeDist(d, name, folder):
	
	total = len(d)
	x = np.linspace(0,40,1000)
	y = []
	for i in x:
		n = len([j for j in d if j <= i])
		y.append(float(n)/float(total))
	
	plt.clf()
	plt.plot(x,y)
	plt.ylabel("% of Events")
	plt.xlabel("log10(EMD) cut")
	plt.title("Cumulative Distribution of {} Random Comparisons".format(name))
	plt.savefig("img/{}/{}-cumulative-dist.png".format(folder, name))
	return y
	
def S2N(S, N, name, folder):
	x = np.linspace(0,40,1000)
	xp = []
	y = []
	print("______________________")
	print(name + " S2N:")
	for i in range(len(x)):
		dS = S[i]
		dN = N[i]
		if(dN != 0):
			y.append(dS/dN)
			xp.append(x[i])
			if(10**x[i] < 50):
				print("cut (EMD): " + str(round(10**x[i],3)) + " -> S2N = " + str(round(dS,4)) + "/" + str(round(dN,4)) + " = " + str(round(dS/dN,3)))
	
	plt.clf()
	plt.plot(xp[:100], y[:100])
	plt.ylabel("Efficiency of Signal / Efficiency of Noise")
	plt.xlabel("log10(EMD) cut")
	plt.title("Efficiency of Signal to Noise for EMD of Random Comparisons")
	plt.savefig("img/{}/{}-S2N.png".format(folder, name))
	
	return y
	
	
def Q(S, N, name, folder):
	x = np.linspace(0,40,1000)
	y = []
	xp =[]
	print("______________________")
	print(name + " Q:")
	
	for i in range(len(x)):
		dS = S[i]
		dN = N[i]
		if(dN != 0):
			xp.append(x[i])
			y.append(dS/dN**.5)
			if(10**x[i] < 50):
				print("cut (EMD): " + str(round(10**x[i],4)) + " -> Q = " + str(round(dS/dN**.5,4)))
	plt.clf()
	plt.plot(xp[:100], y[:100])
	plt.ylabel("Efficiency of Signal / Efficiency of Noise**.5")
	plt.xlabel("log10(EMD) cut")
	plt.title("Q value for EMD of Random Comparisons".format(name))
	plt.savefig("img/{}/{}-Q.png".format(folder, name))
	
	return y

def getFN(p,e,f,a):
	return '/media/shivang/XCD2/EFA/{}-E{}-F{}-Z{}-events.pkl'.format(p,e,f,a)

def exists(p,e,f,a):
	return (os.path.isfile(getFN(p,e,f,a)))
	

def getRFN(p, e, f):
	return '/media/shivang/XCD2/EF/{}-E{}-F{}-events.pkl'.format(p,e,f)
	
def Rexists(p, e, f):
	return (os.path.isfile(getRFN(p,e,f)))


gammt = load_obj(getRFN('g', 1, 1))
datat = load_obj(getRFN('d', 1, 1))

evGam = [Event(0,0,0,0,0,0,0,0,0,0).listLoad(l) for l in gammt[:10000]]
evBkgrnd = [Event(0,0,0,0,0,0,0,0,0,0).listLoad(l) for l in datat[:10000]]
print(len(evGam))
ev = []
n = 0
for i in evGam:
	EMD = []
	for j in evGam:
		EMD.append(i.compare(j))
	m = sorted(EMD)[len(EMD)//2]
	print("event {} done: \t median EMD:{}".format(n,m))
	n+=1
	ev.append((m,i))


ev.sort(key = lambda x: x[0])
for i in range(100):
	ev[i][1].plotSpace(ev[i][0], "img/E1F1/")
	


'''
prefixes = ['g','d']

s2ns = []
qs = []
gcumuls = []
dcumuls = []

for b in sorted(ps.EFBins):
	gammt = []
	datat = []
	range1 = 0
	if(Rexists('g', b[0], b[1]) and Rexists('d', b[0], b[1])):
		gammt = load_obj(getRFN('g', b[0], b[1]))
		datat = load_obj(getRFN('d', b[0], b[1]))
		
		glen = len(gammt)
		dlen = len(datat)
		range1 = glen
		if dlen < glen:
			range1 = dlen
		
	else:
		continue

	print("loaded:E{}F{}:\tg:{}\td:{}".format(b[0],b[1], len(gammt), len(datat)))

	
	
	
	
	evGam = [Event(0,0,0,0,0,0,0,0,0,0).listLoad(l) for l in gammt[:range1]]
	evBkgrnd = [Event(0,0,0,0,0,0,0,0,0,0).listLoad(l) for l in datat[:range1]]

	print("converted:E{}F{}".format(b[0],b[1]))

	for i in evGam:
		if i.par_type != "gamma":
			print("error event not gamma")
			
	for i in evBkgrnd:
		if i.par_type != "data":
			print("error event not data")
		
	print("identified:E{}F{}".format(b[0],b[1]))


	folder = "E{}F{}".format(b[0], b[1])
	if not os.path.exists("img/{}".format(folder)):
		os.mkdir("img/{}".format(folder))
		
	gamP = RandComp1(evGam)
	bkgP = RandComp1(evBkgrnd)
	bothP = RandComp2(evGam, evBkgrnd)

	gamS = cumulativeDist(gamP, "Gamma", folder)
	bkgS = cumulativeDist(bkgP, "Bkgrnd", folder)
	bothS = cumulativeDist(bothP, "Gamma-Bkgrnd", folder)

	S2NDist = S2N(gamS, bkgS, "Gamma-Bkgrnd", folder)
	QDist = Q(gamS, bkgS, "Gamma-Bkgrnd", folder)

	z = [i for i in bkgS if i == 0]
	d = len(z)

	cutPoints = np.linspace(0,40,1000)[d:]
	EffG = gamS[d:]
	EffD = bkgS[d:]
	
	row = 1
	workbook = xlsxwriter.Workbook('img/{}/E{}F{}-{}events.xlsx'.format(folder,b[0],b[1],range1))
	worksheet = workbook.add_worksheet()
	worksheet.write(0,0,"CUT POINT EMD")
	worksheet.write(0,1,"Gamma Efficiency")
	worksheet.write(0,2,"Data Efficiency")
	worksheet.write(0,3,"S2N")
	worksheet.write(0,4,"Q-Value")
	
	
	for i in range(100):
		rowElems = [10**cutPoints[i], EffG[i], EffD[i], S2NDist[i], QDist[i]]
		col = 0
		for j in rowElems:
			worksheet.write(row, col, j)
			col+=1
		row+=1
		
	workbook.close()
	
	plt.clf()
	
	plt.plot(gamS[d:],QDist)
	plt.ylabel("Q-value")
	plt.xlabel("Efficiency of Signal")
	plt.title("Q value vs Gamma Signal Efficiency for EMD of Random Comparisons")
	plt.savefig("img/{}/QvG.png".format(folder))
'''


