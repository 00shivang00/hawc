

from xcdf import XCDFFile
import math

import energyflow as ef
from energyflow.datasets import qg_jets
from energyflow.utils import data_split, standardize, to_categorical
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt

import os
import numpy as np
from optparse import OptionParser
import matplotlib.pyplot as plt

from PosLookUp import xCh, yCh

"""
def dot(x, y):
    return sum([x[i] * y[i] for i in range(len(x))])

def v_len(x):
    return (dot(x, x))**.5

def normal(x):
    return [x[i] / v_len(x) for i in range(len(x))]

def project_onto_plane(x, n):
    d = dot(x, n) / v_len(n)
    p = [d * normal(n)[i] for i in range(len(n))]
    return [x[i] - p[i] for i in range(len(x))]


def proj(x,y,zen,az):
	n = s2rec(zen,az)
	v = [x,y,0]
	p = project_onto_plane(v,n)
	return rt(zen, az,p)
	
def s2rec(theta,phi):
	x = np.sin(theta)*np.cos(phi)
	y = np.sin(theta)*np.sin(phi)
	z = np.cos(theta)
	return [x,y,z]
	
def avg(l):
	return sum(l)/len(l)

def rt(theta,phi,v):
	phi = -phi
	theta = -theta
	Rx = np.array([[1,0,0],
				  [0, np.cos(theta),-np.sin(theta)],
				  [0, np.sin(theta),np.cos(theta)]])

	Rz = np.array([[ np.cos(phi),-np.sin(phi),0],
				  [ np.sin(phi),np.cos(phi),0],
				  [0,0,1]])
	Ry = np.array([[np.cos(theta),0,np.sin(theta)],
				   [0,1,0],
				   [-np.sin(theta),0,np.cos(theta)]])

	return Ry.dot(Rz.dot(v))

def transform(ev):
	az = ev[2]
	zen = ev[1]
	
	#print('________________________________________________') 
	#print("for az = " + str(round(az+np.pi,4)) + ", and zen = " + str(round(zen,4)))
	#print('________________________________________________')
	
	for i in range(len(ev[0][0])):
		az = ev[2] + np.pi
		zen = ev[1]
		v = proj(ev[0][2][i], ev[0][3][i],zen,az)
	#	print(round(ev[0][2][i],4), round(ev[0][3][i],4)," transforms to ", round(v[0],4), round(v[1],4))
		ev[0][2][i], ev[0][3][i] = -1*v[0], -1*v[1]
	return ev
	

"""

n=0
xscale = 1.0
yscale = 1.0
#for i in range(0,1124):
#	plt.plot([xCh[i]] , [yCh[i]], marker='o', markersize=1, color = 'blue')
xf = XCDFFile("out-file.xcd")
histl = []
xcl = []
ycl = []
for r in xf.fields(" rec.angleFitStatus, rec.coreFitStatus, rec.nHit, mc.coreX, mc.coreY, rec.coreX, rec.coreY, mc.delCore, mc.delAngle"):
	angfit = r[0]
	corefit = r[1]
	nhit = r[2]
	MCxC = r[3] 
	MCyC = r[4] 
	recxC = r[5] 
	recyC = r[6] 
	delCore = r[7]
	delAngle = r[8]
	
	

	if(((angfit == 0) and (corefit == 0))):
		#histl.append(delCore)
		#histl.append(delAngle)
		histl.append(nhit)
		xcl.append(MCxC)
		ycl.append(MCyC)
	n+=1
	if (n >= 1000000):
		break;

plt.hist(histl, np.linspace(0,1000,100))
plt.title("nHit for Events: ((angfit == 0) and (corefit == 0))")
#plt.scatter(xcl, ycl, marker = 'o', s = 1)
plt.show()
