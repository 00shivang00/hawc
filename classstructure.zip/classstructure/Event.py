
from __future__ import division
from xcdf import XCDFFile
import math
import sys
import energyflow as ef
from energyflow.datasets import qg_jets
from energyflow.utils import data_split, standardize, to_categorical
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt
import random

import os
import numpy as np
from optparse import OptionParser
import matplotlib.pyplot as plt
import curses 
from collections import defaultdict
from PosLookUp import *
from scipy.spatial.transform import Rotation as R




class Event:
	def listLoad(self, l):
		self.xC = l[0]
		self.yC = l[1]
		self.nHit = l[2]
		self.LTeV = l[3]
		self.fHit = l[4]
		self.zen = l[5]
		self.az = l[6]
		self.fbin = l[7]
		self.ebin = l[8]
		self.eta = l[9]
		self.phi = l[10]
		self.Q = l[11]
		self.zeros = l[12]
		self.par_type = l[13]
		self.transformed = l[14]
		self.fid = l[15]
		self.delAng = l[16]
		return self
	
	def __init__(self, xcore, ycore, N, E, F, Z, A, Eb, Fb, fid):
		self.xC = xcore
		self.yC = ycore
		self.nHit = N
		self.LTeV = E
		self.fHit = F
		self.zen = Z
		self.az = A
		self.fbin = Fb
		self.ebin = Eb
		self.eta = []
		self.phi = []
		self.Q = []
		self.zeros = []
		self.fid = fid
		self.par_type = ""
		self.delAng = None
		self.transformed = False
		
	def transform(self):
		if(not(self.transformed)):
			transform(self)
		self.transformed = True
		
	def mean(self):
		return [np.mean(self.eta), np.mean(self.phi)]
	
	def variance(self):
		v1 = sum([((j - np.mean(self.eta))**2)/len(self.eta) for j in eta ])
		v2 = sum([((j - np.mean(self.phi))**2)/len(self.phi) for j in phi ])
		return [v1, v2]
		
	def std(self):
		return ([i**.5 for i in self.variance()])
	
	def RMS(self):
		return [round(np.sqrt(np.mean([i**2 for i in self.eta])),4), round(np.sqrt(np.mean([i**2 for i in self.phi])),4)]
		
	def plot(self):
		b1 = np.linspace(-5,5, 35)
		b2 = np.linspace(-5,5, 35)
		
		plt.clf()
		plt.title('Eta:(zen= {}, az= {}, log(TeV)= {}, fHit= {})'.format(self.zen, self.az, self.LTeV, self.fHit))
		plt.hist(self.eta, bins = b1)
		EtaH, EtaBins = np.histogram(self.eta, bins = b1)
		plt.ylim((0, max(EtaH) * 1.5))
		plt.text(3, max(EtaH),'Entries: {} \nRMS: {} \nMean: {} \nVar: {}\n STD: {}'.format(len(self.eta), round(np.sqrt(np.mean([i**2 for i in self.eta])),4),
		round(np.mean(self.eta), 4), round(np.var(self.eta) ,4), round(np.std(self.eta), 4)), ha='left', va='bottom')
		plt.savefig('img/{} {}_{} Eta.png'.format(self.par_type, n2l[self.ebin], self.fbin))


		plt.clf()
		plt.title('Phi:(zen= {}, az= {}, log(TeV)= {}, fHit= {})'.format(self.zen, self.az, self.LTeV, self.fHit))
		plt.hist(self.phi, bins = b2)
		PhiH, PhiBins = np.histogram(self.phi, bins = b2)
		plt.ylim((0, max(PhiH) * 1.5))
		plt.text(2, max(PhiH),'Entries: {} \nRMS: {} \nMean: {} \nVar: {} \nSTD: {}'.format(len(self.phi), round(np.sqrt(np.mean([i**2 for i in self.phi])),4), 
		round(np.mean(self.phi), 4), round(np.var(self.phi),4), round(np.std(self.phi), 4)), ha='left', va='bottom')
		plt.savefig('img/{} {}_{} Phi.png'.format(self.par_type, n2l[self.ebin], self.fbin))
		
	def plotSpace(self, emd, sub):
		plt.clf()
		plt.title('(zen= {}, az= {}, log(TeV)= {}, fHit= {}, emd = {})'.format(round(self.zen,3), round(self.az,3), round(self.LTeV,3), round(self.fHit,3), round(emd,3)))
		plt.scatter(self.eta, self.phi, c=[np.log10(i) for i in self.Q], s=10)
		plt.gray()
		plt.savefig(sub + '{} {}_{} {}.png'.format(self.par_type, self.ebin, self.fbin, round(emd,4)))
		
		
	def get_ev(self):
		return [self.Q[:], self.eta[:], self.phi[:], self.zeros[:]]
		
	def rotate(self, a):
		z = [0 for i in range(len(self.eta))]
		v = zip(self.eta,self.phi,z)
		v = [list(i) for i in v]
		etaP = []
		phiP = []
		theta = 0.0
		Ry = np.array([[np.cos(theta),0,np.sin(theta)],
					   [0,1,0],
					   [-np.sin(theta),0,np.cos(theta)]])
		Rz = np.array([[ np.cos(a),-np.sin(a),0],
					  [ np.sin(a),np.cos(a),0],
					  [0,0,1]])
		for i in v:
			j = (Rz.dot(i))
			etaP.append(j[0])
			phiP.append(j[1])
	
		self.eta = etaP
		self.phi = phiP
		return 
	
	def stabilize(self):
		x1 = sum(self.eta)/len(self.eta)
		y1 = sum(self.phi)/len(self.phi)
		a1 = np.arctan(y1/x1)
		self.rotate(-a1)
		
	def compare(self, ev):
		s1 = self.get_ev()
		s2 = ev.get_ev()
		'''
		x1 = sum(s1[1])/len(s1[1])
		y1 = sum(s1[2])/len(s1[2])
		x2 = sum(s2[1])/len(s2[1])
		y2 = sum(s2[2])/len(s2[2])
		
		a1 = np.arctan(y1/x1)
		a2 = np.arctan(y2/x2)
		
		self.rotate(-a1)
		ev.rotate(-a2)
		s1 = self.get_ev()
		s2 = ev.get_ev()
		'''
		return ef.emd.emd(s1, s2, measure='spherical')
		
	def evListForm(self):
		return [self.xC, self.yC, self.nHit, self.LTeV, self.fHit, self.zen, self.az, self.fbin, self.ebin, self.eta, self.phi, self.Q, self.zeros, self.par_type, self.transformed, self.fid, self.delAng]
 
	
	
