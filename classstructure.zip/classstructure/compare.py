#!/usr/bin/env python
################################################################################
# A demonstration of how to call the AERIE detector-service inside of python.  #
#                                                                              #
# To use this program AERIE must be installed and /path/to/aerie/lib must be   #
# included in your PYTHONPATH environment variable.  The environment is set up #
# with the hawc-config script:                                                 #
#                                                                              #
#   $> eval `/path/to/aerie/bin/hawc-config --env-sh`                          #
################################################################################


from xcdf import XCDFFile
import math
import sys
import energyflow as ef
from energyflow.datasets import qg_jets
from energyflow.utils import data_split, standardize, to_categorical
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt
import random

import os
import numpy as np
from optparse import OptionParser
import matplotlib.pyplot as plt
import curses 
from collections import defaultdict

from PosLookUp import *
n=0


scale = 250.0

minE = 50
maxE = 1000
name = "/media/shivang/xcd/data.xcd"

#for num in range(0,9):
	#name = "proton{}.xcd".format(num)

xf = XCDFFile(name)
					#12 = index for last item



#(1,2,8),(2,3,6) (2,3)
def expandPosEv(ev, d):

	
	for i in range(len(ev[1])):
		x,y = ev[1][i],ev[2][i]

		R = (x**2 + y**2)**.5
		t = np.arctan(y/x)
		R += d*R
		
		x = R*np.cos(t)
		y = R*np.sin(t)
		
		ev[1][i] = x
		ev[2][i] = y
	return ev


def expandQEv(ev, d):
	evc = [i[:] for i in ev]
	for i in range(len(evc[1])):
		evc[0][i] = evc[0][i]*d
	return evc
	
def rotateEv(ev, a):
	eta = ev[1][:]
	phi = ev[2][:]
	z = [0 for i in range(len(eta))]
	v = zip(eta,phi,z)
	v = [list(i) for i in v]
	etaP = []
	phiP = []
	theta = 0.0
	Ry = np.array([[np.cos(theta),0,np.sin(theta)],
				   [0,1,0],
				   [-np.sin(theta),0,np.cos(theta)]])
	Rz = np.array([[ np.cos(a),-np.sin(a),0],
				  [ np.sin(a),np.cos(a),0],
				  [0,0,1]])
	for i in v:
		j = (Rz.dot(i))
		
		etaP.append(j[0])
		phiP.append(j[1])
	
	
	
	
	return list((ev[0],etaP, phiP, ev[3]))
			

eCount = {}
fCount = {}
stage = [[1,2,3,4,5,6,7,8]]
paths = [ "none","fid", "fid-and-zen", "zen" ]
paths = [ "none" ]
ev = None
pret = None
for pI in range(len(paths)):
	print(paths[pI] + ": ")
	xf = XCDFFile(name)
	for fB in stage:
		
		n = 0
		k = 0
		if fB == -1:
			continue
		EFhit_dict = {}
		print("searching: ",fB)
		for r in xf.fields(" event.nHit, event.hit.gridId, event.hit.charge, rec.zenithAngle, rec.azimuthAngle, rec.coreX, rec.coreY, rec.nChAvail, rec.logNNEnergy, rec.coreFitStatus, rec.angleFitStatus, rec.coreFiduScale"):
		#for r in xf.fields(" event.nHit, event.hit.gridId, event.hit.charge, rec.zenithAngle, rec.azimuthAngle, rec.coreX, rec.coreY, rec.nChAvail, rec.logNNEnergy, rec.coreFitStatus, rec.angleFitStatus, rec.coreFiduScale, mc.delAngle"):
			
			
			#nHit, ids, Q, zen, az, xC, yC, nCh, logGeV, coreFit, angFit, fid, delAng = r
			nHit, ids, Q, zen, az, xC, yC, nCh, logGeV, coreFit, angFit, fid = r
			#0     1   2   3    4   5   6   7    8        9         10    11
			if n%100000 == 0:				
				print("explored vs found in this bin: " + str(n) + " vs " + str(k))	
			if n==200000:
					print("bruh")
					break

			fh = (1.0 * nHit)/(1.0 * nCh)
			E = 10**(logGeV - 3)
			en = eNum(E)
			fn = fNum(fh)
			if ((fn in fB) and (en > -1)):
				
				
				if((en, fn) in EFhit_dict.keys()) and (len(EFhit_dict[(en, fn)]) >= 15):
					n+=1
					continue
				
				
				bools = [((angFit + coreFit) == 0) and (fid <= 150), ((angFit + coreFit) == 0) and (fid <= 80), ((angFit + coreFit) == 0) and (zen <= 0.523) and (fid <= 80), ((angFit + coreFit) == 0) and (zen <= 0.523)]
				#if((delAng < .087) and ((angFit + coreFit) == 0) and (fid <= 150)):
				if(bools[pI]):
					k+=1
					ev = Event(xC, yC, nHit, E, fh, zen, az, en, fn)
					ev.par_type = "data"
					for i in range(0,nHit):
						ind = ids[i]	#pmt index
						
						if(ind<1124):
							ev.zeros.append(1.0)
							ev.Q.append(Q[i])							#charge
							ev.eta.append(np.pi*((xCh[ind]-xC)/scale))	#X position from core (eta)
							ev.phi.append(np.pi*((yCh[ind]-yC)/scale))	#Y position from core (phi)
					
					if((en, fn) not in EFhit_dict.keys()):
						EFhit_dict[(en, fn)] = []
					ev.transform()
					EFhit_dict[(en, fn)].append(ev)
				
			n+=1
		 

		d = 1.1
		
		
		for i in EFhit_dict.keys():
			ev = EFhit_dict[i][0]
			ev1 = ev.get_ev()
			x = np.linspace(1.0,1.5,100)
			y = []
			ev1tmp = [k[:] for k in ev1]
			for i in x:
				
				ev1p = expandQEv(ev1tmp, i)
				y.append(ef.emd.emd(ev1tmp, ev1p, measure='spherical'))
			plt.clf()
			plt.plot(x,y)
			plt.title("EMD of Charge Expanded Event in Bin {}-{}".format(n2l[ev.ebin], ev.fbin))
			plt.xlabel("Scale")
			plt.ylabel("EMD")
			plt.savefig('img/{} {}_{} charge.png'.format(ev.par_type, n2l[ev.ebin], ev.fbin))
			#print(ef.emd.emd(ev0, ev1, measure='spherical'))
	

	



