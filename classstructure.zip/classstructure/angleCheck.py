#!/usr/bin/env python
################################################################################
# A demonstration of how to call the AERIE detector-service inside of python.  #
#                                                                              #
# To use this program AERIE must be installed and /path/to/aerie/lib must be   #
# included in your PYTHONPATH environment variable.  The environment is set up #
# with the hawc-config script:                                                 #
#                                                                              #
#   $> eval `/path/to/aerie/bin/hawc-config --env-sh`                          #
################################################################################

from __future__ import division
from xcdf import XCDFFile
import math
import sys
import energyflow as ef
from energyflow.datasets import qg_jets
from energyflow.utils import data_split, standardize, to_categorical
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt
import random


import os
import numpy as np
from optparse import OptionParser
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import curses 
from collections import defaultdict
from scipy.spatial.transform import Rotation as R

from PosLookUp import *

def goPlot(ev, zen, az, eb, fb):
	ze = np.zeros(len(ev[0]))
	
	normal = s2rec(zen, az)
	print(normal)
	
	# create x,y
	xx, yy = np.meshgrid(range(-2,2), range(-2,2))

	# calculate corresponding z
	z = (-normal[0] * xx - normal[1] * yy) * 1. /normal[2]

	# plot the surface
	plt3d = plt.figure().gca(projection='3d')
	plt3d.plot_surface(xx, yy, z, alpha=0.2)
	x,y,z = [],[],[]
	for i in range(len(ev[0])):
		v = [ev[1][i], ev[2][i], 0]
		
		p = project_onto_plane(v,normal)
		x.append(p[0])
		y.append(p[1])
		z.append(p[2])
	rx,ry,rz = [],[],[]
	for i in range(len(x)):
		p = proj(ev[1][i], ev[2][i], zen, az)
		rx.append(p[0])
		ry.append(p[1])
		rz.append(p[2])
		
	ax = plt.gca()
	ax.hold(True)

	ax.scatter(x , y , z,  color='red')
	
	ax.hold(True)

	ax.scatter(ev[1], ev[2], ze,  color='green')
	
	ax.hold(True)

	
	ax.scatter(rx, ry, rz,  color='orange')
	plt.title(str(len(rx)) + " hit " + str(eb) + " - " + str(fb) + " event")
	plt.show()
	"""
	for i in xrange(0,360, 90):
		ax.view_init(elev=13., azim=i)
		plt.savefig("angIMG/" + str(en) + "-" + str(fb) + " event" + " at " + str(i) + " degrees")
	"""



n=0


scale = 250.0

minE = 50
maxE = 1000
name = "/media/shivang/xcd/gamma.xcd"

#for num in range(0,9):
	#name = "proton{}.xcd".format(num)


					#12 = index for last item


eCount = {}
fCount = {}
stage = [[0,1,2,3,4,5,6,7,8]]
paths = [ "none","fid", "fid-and-zen", "zen"]
paths = [ "none"]

pre = 0;
post = 0;
for pI in range(len(paths)):
	print(paths[pI] + ": ")
	
	for fB in stage:
		xf = XCDFFile(name)
		fin = []
		n = 1
		k = 0
		if fB == -1:
			continue
		EFhit_dict = {}
		print("searching: ",fB)
		#for r in xf.fields(" event.nHit, event.hit.gridId, event.hit.charge, rec.zenithAngle, rec.azimuthAngle, rec.coreX, rec.coreY, rec.nChAvail, rec.logNNEnergy, rec.coreFitStatus, rec.angleFitStatus, rec.coreFiduScale"):
		for r in xf.fields(" event.nHit, event.hit.gridId, event.hit.charge, rec.zenithAngle, rec.azimuthAngle, rec.coreX, rec.coreY, rec.nChAvail, rec.logNNEnergy, rec.coreFitStatus, rec.angleFitStatus, rec.coreFiduScale, mc.delAngle"):
			
			nHit, ids, Q, zen, az, xC, yC, nCh, logGeV, coreFit, angFit, fid, delAng = r
			#nHit, ids, Q, zen, az, xC, yC, nCh, logGeV, coreFit, angFit, fid = r
			#0     1   2   3    4   5   6   7    8        9         10    11
			if n%100000 == 0:
				print("explored vs found in this bin: " + str(n) + " vs " + str(k))	
			

			fh = (1.0 * nHit)/(1.0 * nCh)
			E = 10**(logGeV - 3)
			en = bNum(E,l=eBin)
			fn = bNum(fh,l=fBin)
			if ((fn in fB) and (en > -1)):
				
				
				if((en,fn) in fin) or (((en, fn) in EFhit_dict.keys()) and (EFhit_dict[(en, fn)].n >= 10000)):
					n+=1
					if (en, fn) not in fin:
						fin.append((en,fn))
						EFhit_dict[(en, fn)].plot()	
						print("finished: " + str((en, fn)))
						EFhit_dict[(en, fn)] = None
					continue
				
				
				bools = [((angFit + coreFit) == 0) and (fid <= 150), ((angFit + coreFit) == 0) and (fid <= 80), ((angFit + coreFit) == 0) and (zen <= 0.523) and (fid <= 80), ((angFit + coreFit) == 0) and (zen <= 0.523)]
				#if((delAng < .087) and ((angFit + coreFit) == 0) and (fid <= 150)):
				if((delAng < .087) and bools[pI]):
					k+=1
					ev = Event(xC, yC, nHit, E, fh, zen, az, en, fn)
					ev.par_type = "gamma"
					for i in range(0,nHit):
						ind = ids[i]	#pmt index
						
						if(ind<1124):
							ev.zeros.append(0.0)
							ev.Q.append(Q[i])							#charge
							ev.eta.append(np.pi*((xCh[ind]-xC)/scale))	#X position from core (eta)
							ev.phi.append(np.pi*((yCh[ind]-yC)/scale))	#Y position from core (phi)
					
					if((en, fn) not in EFhit_dict.keys()):
						EFhit_dict[(en, fn)] = Collection(en, fn, "gamma", paths[pI])
					pre = ev.get_ev()
					goPlot(pre, zen, az, en, fn)
					ev.transform()
					post = ev.get_ev()
					
					print(zen, az)
					EFhit_dict[(en, fn)].add_event(ev)
			n+=1
			if n == 60 :
				break





