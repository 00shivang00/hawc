#!/usr/bin/env python
################################################################################
# A demonstration of how to call the AERIE detector-service inside of python.  #
#                                                                              #
# To use this program AERIE must be installed and /path/to/aerie/lib must be   #
# included in your PYTHONPATH environment variable.  The environment is set up #
# with the hawc-config script:                                                 #
#                                                                              #
#   $> eval `/path/to/aerie/bin/hawc-config --env-sh`                          #
################################################################################

from __future__ import division
import ROOT
from matplotlib.colors import LogNorm
from xcdf import XCDFFile
import math
import sys
import energyflow as ef
from energyflow.datasets import qg_jets
from energyflow.utils import data_split, standardize, to_categorical
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt
import random
from tabulate import tabulate
import os
import numpy as np
from optparse import OptionParser
import matplotlib.pyplot as plt
import curses 
from collections import defaultdict

from PosLookUp import *
n=0


scale = 250.0

minE = 50
maxE = 1000
#name = "/media/shivang/xcd/gamma.xcd"
name = "/media/shivang/xcd/data.xcd"

#for num in range(0,9):
	#name = "proton{}.xcd".format(num)


					#12 = index for last item

lim = 2E6
zen_hists = {}
az_hists = {}



paths = ["fid <= 150", "fid <= 80", "fid <= 80 and zen <= 0.523", "zen <= 0.523"]
for pI in [0]:
	xf = XCDFFile(name)
	baseEs = []
	baseFs = []

	cutEs = []
	cutFs = []
	print(paths[pI] + ": ")
	n=0
	#for r in xf.fields(" event.nHit, event.hit.gridId, event.hit.charge, rec.zenithAngle, rec.azimuthAngle, rec.coreX, rec.coreY, rec.nChAvail, rec.logNNEnergy, rec.coreFitStatus, rec.angleFitStatus, rec.coreFiduScale, mc.delAngle"):
	for r in xf.fields(" event.nHit, event.hit.gridId, event.hit.charge, rec.zenithAngle, rec.azimuthAngle, rec.coreX, rec.coreY, rec.nChAvail, rec.logNNEnergy, rec.coreFitStatus, rec.angleFitStatus, rec.coreFiduScale"):
			n+=1
			
			if n%250000 == 0:
				print("explored in this bin: " + str(n))	
			#nHit, ids, Q, zen, az, xC, yC, nCh, logGeV, coreFit, angFit, fid, delAng = r
			nHit, ids, Q, zen, az, xC, yC, nCh, logGeV, coreFit, angFit, fid= r
			#0     1   2   3    4   5   6   7    8        9         10    11
			
			

			fh = (1.0 * nHit)/(1.0 * nCh)
			E = 10**(logGeV - 3)
			en = eNum(E, l=SMeBin)
			fn = fNum(fh, l=SMfBin)
			
			if (fn < 0) or (en < 0):
				n+=1
				continue
			
			bools = [((angFit + coreFit) == 0) and (fid <= 150)]
			if (en,fn) not in zen_hists.keys():
				zen_hists[(en,fn)] = []
			if (en,fn) not in az_hists.keys():
				az_hists[(en,fn)] = []

			#if((delAng < .087) and bools[pI]):
			if(bools[pI]):
				zen_hists[(en,fn)].append(zen)
				az_hists[(en,fn)].append(az)

			if n == lim:
				break
	

	b1 = np.linspace(-0.5,1.5,50)
	b2 = np.linspace(-3.5,3.5,50)

	for i in sorted(zen_hists.keys()):
		print(i)
		h = np.histogram(zen_hists[i], bins=b1, density=True)
		plt.hist(zen_hists[i], bins=b1, density=True)
		plt.ylabel("Event Frequency")
		plt.xlabel("Zenith Angle [Radians]")
		plt.title(str(i[0]) + "-" + str(i[1]) + " Zenith with " + paths[pI])
		plt.text(1, max(h[0]) * .75,'Entries: {} \nRMS: {} \nMean: {} \nVar: {} \nSTD: {}'.format(len(zen_hists[i]), round(np.sqrt(np.mean([j**2 for j in zen_hists[i]])),4), 
		round(np.mean(zen_hists[i]), 4), round(np.var(zen_hists[i]),4), round(np.std(zen_hists[i]), 4)), ha='left', va='bottom')
		plt.savefig("zen/"+"zen in "+str(i[0]) + "_" + str(i[1]) + " " + paths[pI] + ".png")
		plt.clf()


	for i in sorted(az_hists.keys()):
		print(i)
		h = np.histogram(az_hists[i], bins=b2, density=True)
		plt.hist(az_hists[i], bins=b2, density=True)
		plt.ylabel("Event Frequency")
		plt.xlabel("Azimuth Angle [Radians]")
		plt.title(str(i[0]) + "-" + str(i[1]) + " Azimuth with " + paths[pI])
		plt.text(2, max(h[0]) * .75,'Entries: {} \nRMS: {} \nMean: {} \nVar: {} \nSTD: {}'.format(len(az_hists[i]), round(np.sqrt(np.mean([j**2 for j in az_hists[i]])),4), 
		round(np.mean(az_hists[i]), 4), round(np.var(az_hists[i]),4), round(np.std(az_hists[i]), 4)), ha='left', va='bottom')
		plt.savefig("az/"+"az in " + str(i[0]) + "_" + str(i[1]) + " " + paths[pI] + ".png")
		plt.clf()


