
from __future__ import division
from xcdf import XCDFFile
import math
import sys
import energyflow as ef
from energyflow.datasets import qg_jets
from energyflow.utils import data_split, standardize, to_categorical
from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt
import random


import os
import numpy as np
from optparse import OptionParser
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import curses 
from collections import defaultdict
from scipy.spatial.transform import Rotation as R
import pickle
from PosLookUp import *
from Event import *

def save_obj(obj, name ):
    with open('/media/shivang/XCD2/Snz/'+ name + '.pkl', 'wb') as f:
        pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)

def EvBin(a, b, s):
	dEB = a
	dFB = b
	scale = 250.0
	
	minE = 50
	maxE = 1000
	name = "/media/shivang/xcd/" + s + ".xcd"
	eCount = {}
	fCount = {}
	paths = [ "none","fid", "fid-and-zen", "zen" ]
	paths = [ "none" ]
	ev = None
	pret = None
	for pI in range(len(paths)):
		print(paths[pI] + ": ")
		xf = XCDFFile(name)
		
		n = 0
		k = 0
		
		EFhit_dict = {}
		print("searching: {}, {}".format(dEB, dFB))
		flds = None
		if s[0] == 'g':
			flds = " event.nHit, event.hit.gridId, event.hit.charge, rec.zenithAngle, rec.azimuthAngle, rec.coreX, rec.coreY, rec.nChAvail, rec.logNNEnergy, rec.coreFitStatus, rec.angleFitStatus, rec.coreFiduScale, mc.delAngle"
		else:
			flds = " event.nHit, event.hit.gridId, event.hit.charge, rec.zenithAngle, rec.azimuthAngle, rec.coreX, rec.coreY, rec.nChAvail, rec.logNNEnergy, rec.coreFitStatus, rec.angleFitStatus, rec.coreFiduScale"	
		
		for r in xf.fields(flds):
			if s[0] == 'g':
				nHit, ids, Q, zen, az, xC, yC, nCh, logGeV, coreFit, angFit, fid, delAng = r
			else:
				nHit, ids, Q, zen, az, xC, yC, nCh, logGeV, coreFit, angFit, fid = r
				delAng = None
			#0     1   2   3    4   5   6   7    8        9         10    11
			

			fh = (1.0 * nHit)/(1.0 * nCh)
			E = 10**(logGeV - 3)
			en = eNum(E)
			fn = fNum(fh)
			an = aNum(zen)
			if ((fn in dFB) and (en == dEB) and an > 0):
				
				
				if((en, fn) in EFhit_dict.keys()) and (len(EFhit_dict[(en, fn)]) >= 30000):
					continue
				
				
				bools = [((angFit + coreFit) == 0) and (fid <= 150), ((angFit + coreFit) == 0) and (fid <= 80), ((angFit + coreFit) == 0) and (zen <= 0.523) and (fid <= 80), ((angFit + coreFit) == 0) and (zen <= 0.523)]
				#if((delAng < .087) and ((angFit + coreFit) == 0) and (fid <= 150)):
				if(bools[0]):
					k+=1
					ev = Event(xC, yC, nHit, E, fh, zen, az, en, fn, fid)
					ev.par_type = s
					for i in range(0,nHit):
						ind = ids[i]	#pmt index
						
						if(ind<1124):
							ev.zeros.append(1.0)
							ev.delAng = delAng
							ev.Q.append(Q[i])							#charge
							ev.eta.append(np.pi*((xCh[ind]-xC)/scale))	#X position from core (eta)
							ev.phi.append(np.pi*((yCh[ind]-yC)/scale))	#Y position from core (phi)
					
					if((en, fn) not in EFhit_dict.keys()):
						EFhit_dict[(en, fn)] = []
					ev.transform()
					#ev.stabilize()
					EFhit_dict[(en, fn)].append(ev.evListForm())
				
				n+=1
			d = 1.1
	return EFhit_dict

fbs = [1,2,3,4,5,6,7,8,9]
ebs = [1,2,3,4,5,6,7,8,9,10,11]
zbs = [1,2,3,4]
name = 'data'
prefix = name[0]
for i in ebs:	
		EFhit_dict = EvBin(i, fbs, name)
		for k in sorted(EFhit_dict.keys()):
			save_obj(EFhit_dict[k], "{}-E{}-F{}-events".format(prefix, k[0], k[1]))	
			print("finished: {} {} - len:{}".format(k[0], k[1], len(EFhit_dict[k])))




